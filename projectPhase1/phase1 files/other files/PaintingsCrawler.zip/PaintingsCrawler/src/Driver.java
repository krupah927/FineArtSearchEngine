/*
 * 
 *Driver class for paintings crawlers. 
 *
 * 
 * 
 * 
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		
		try {
			//read aragument 0 -seed file
			String seedFile=args[0];
			Scanner seeds = new Scanner(new File(seedFile));
			ArrayList<String> seedList = new ArrayList<String>();
			while (seeds.hasNextLine()){
			    seedList.add(seeds.next());
			}
			
			int numOfSeeds=seedList.size();
			int pageLimit=Integer.parseInt(args[1]);
			
			String outputDir=args[2];
			 File directory = new File(outputDir);
			    if (! directory.exists()){
			        directory.mkdir();
			    }
					
			//frontiers for crawlers - for our project we have 5 crawlers so, creating 5 frontiers 
			QueueLinks q1=new QueueLinks();
			QueueLinks q2=new QueueLinks();
			QueueLinks q3=new QueueLinks();
			QueueLinks q4=new QueueLinks();
			QueueLinks q5=new QueueLinks();
			
			
			//hash Set to hold all urls to eliminate duplication
			QueueLinks hashQ= new QueueLinks();
			
			//add seeds to respective crawlers
			q1.addString(seedList.get(0));
			q2.addString(seedList.get(1));
			q3.addString(seedList.get(2));
			q4.addString(seedList.get(3));
			q5.addString(seedList.get(4));
		
		
			hashQ.HashSetCreate();
			//creating threads for different crawlers
			SaatchiCrawler saatchiThread = new SaatchiCrawler(q1,hashQ,pageLimit,outputDir);
			saatchiThread.start();
			
			
			EtsyCrawler etsyThread= new EtsyCrawler(q2,hashQ,pageLimit,outputDir);
			etsyThread.start();
			
			DeviantCrawler deviantThread =new DeviantCrawler(q3, hashQ,pageLimit,outputDir);
			deviantThread.start();
			
			FizdiCrawler fizdiThread =new FizdiCrawler(q4, hashQ,pageLimit,outputDir);
			fizdiThread.start();

			FineArtAmericaCrawler faacThread =new FineArtAmericaCrawler(q5, hashQ,pageLimit,outputDir);
			faacThread.start();
			
			saatchiThread.join();
			etsyThread.join();
			deviantThread.join();
			fizdiThread.join();
			faacThread.join();
			hashQ.writeHashToFile();
			
		}catch(Exception fileExcepttion) {
			System.out.println("cannot read file:"+fileExcepttion);
		}
		
	}

}
