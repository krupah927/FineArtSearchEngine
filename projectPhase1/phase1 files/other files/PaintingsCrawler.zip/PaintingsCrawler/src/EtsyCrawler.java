import java.io.File;
import java.io.PrintWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class EtsyCrawler extends Thread{
	
	QueueLinks Q2 = new QueueLinks(); //pagination q for etsy
	QueueLinks imageLinksEtsy = new QueueLinks(); //queue to hold images to be crawled
	DownloadImages downloadimgEtsy= new DownloadImages(); //to download images
	QueueLinks hashsetQ=new QueueLinks(); //hashset q to check duplication
	public static int[] DELAY = {5,6,7,8}; //to be used in thread.sleep 
	int delayCounter=0; //iterator for delay array
	int pageLimit;
	String outputDir;
	public EtsyCrawler(QueueLinks q2,QueueLinks hs2,int pages,String dir) {
		Q2= q2;
		hashsetQ=hs2;
		pageLimit=pages;
		outputDir=dir;
	}
	 public void run()
	    {
	    	
	        try
	        { 
	        	//jsonWriter object to write json file
	        	JsonWriter jsonwrite =new JsonWriter();
	        	File file = new File(outputDir+"/"+"lastEtsypage.txt");
	        	//these info have to parsed from crawled page initialize everything to null.
	        	String imgurl =null; 
	        	String  imgTitle = null; 
	        	String  size  =""; 
	        	String  author  =null; 
	        	String   authorLink =null; 
	        	String   imgDecsription =null; 
	        	String   price =null; 
	        	String   views =null; //no view
	        	String   fav =null; 
	        	String   medium =null; 
	        	String [] tags=null;
	        	int crawlCounter=1; //limit crawling to certain number of pages
	        	
	        	while(!Q2.isEmpty()) {
	        		try {
	        			String linkToScrape = Q2.getItem(0); //get the link of the page 
	        		
	        			System.out.println("Etsy: "+linkToScrape);
	        			//write the last crawled page
	        			file.createNewFile();
	        			PrintWriter writer = new PrintWriter(file); 
	        			writer.write(linkToScrape);
	        			writer.close();
	        
	        		
	        			Document document = Jsoup.connect(linkToScrape).get(); //connect to the page
	        	
	        		
	        			//get the div containing pics
	        			Elements outerDiv=document.getElementsByAttributeValue("class","mt-xs-2 text-gray text-control");
	        			Elements inn1=outerDiv.select("div.col-group.pl-xs-0.search-listings-group");
	        			Elements inn2=inn1.select("div.col-xs-12.pl-xs-1.pl-md-3");
	        			Elements allimgDiv=outerDiv.select(".clearfix");
	        			Elements rowdiv=allimgDiv.select("div.block-grid-xs-2.block-grid-md-2.block-grid-lg-3.block-grid-xl-4.block-grid-no-whitespace.float-clear.pb-xs-1-5");
	        			Elements paintinglinks=rowdiv.select("a.display-inline-block.listing-link");
	        		
	        			//add image urls to queue
	        			for (Element link : paintinglinks) {
	        				String absHref = link.attr("abs:href");
	        				
	        				//Check if image link is already taken
	        				if(! hashsetQ.crawledpages.contains(absHref)) {
	        					hashsetQ.crawledpages.add(absHref);
	        					imageLinksEtsy.addString(absHref);
	        				}
	        				
	        			}
	        			
	        			
	        			//get next page link and add to queue
	        			Element paginationDiv=document.select("div.mb-xs-5.mt-xs-3 a").last();
	        			String nextpage=paginationDiv.attr("abs:href");
	        			
	        			
	        			if(crawlCounter<pageLimit) {
	            			//add the next page url to q1
	        				Q2.addString(nextpage);
	            					crawlCounter++;
	            			}
	        			
	        			
	        			
	        			//wait for sometime
	        			Thread.sleep(DELAY[delayCounter%4]*1000);
	        			delayCounter++;
	        			
	        			while(!imageLinksEtsy.isEmpty()) {
	        				try {
	        					
	        					//get image link to crawl.
	        					String imgLinkToCrawl=imageLinksEtsy.getItem(0);
	        					
	        					System.out.println("Etsy crawling image:" + imgLinkToCrawl);
	        					
	        					//connect to the image page
	        					Document imgDocument = Jsoup.connect(imgLinkToCrawl).get();
	        			 
	        					//get image name
	        					Elements imginfoDiv=imgDocument.select("div#listing-right-column");
	        					Elements imgName=imginfoDiv.select(".p-xs-2.p-md-0.bg-white h1 span");
	        					imgTitle=imgName.text();
	        			 
	        					//get price
	        					Elements priceDiv=imginfoDiv.select(".buy-box__price.ui-toolkit").select("span");
	        					price=priceDiv.text().split(" ")[0];
	        			
	        					//get image informations
	        					Elements overviewDiv=imginfoDiv.select("div#item-overview").select("ul").first().select("li");
	        					int i=0;
	        					String[] temp=null;
	        					String overviewInfo=null;
	        					for(Element info :overviewDiv) {
	        						overviewInfo=info.text();
	        						temp=overviewInfo.split(":");
	        				
	        						if(temp[0].equals("Height") || temp[0].equals("Width")) {
	        							size=size+temp[1]+"x";
	        						}
	        						if(temp[0].equals("Materials")||temp[0].equals("Material"))
	        							medium=temp[1];
	        						if(temp[0].equals("Favorited by"))
	        							fav=temp[1];
	        					
	        					}
	        					//get image div
	        					Elements imageDiv=imgDocument.select("div.col.col7.fix570");
	        					//get description 
	        					Elements imageDescriptionDiv=imageDiv.select("div#description-text");
	        					imgDecsription=imageDescriptionDiv.text();
	        			
	        					//get imgsrc
	        					Element imageSource=imageDiv.select("div#image-main").select("ul").select("li").first();
	        					imgurl=imageSource.select("img").attr("src");
	        			
	        					//author and author links
	        					Elements authorDiv=imginfoDiv.select("div#shop-info").select("div.shop-name a");
	        					author=authorDiv.text();
	        					authorLink=authorDiv.attr("abs:href");
	        			 
	        					//get tags
	        					Elements tagDiv=imgDocument.select("div.content-wrap-inner-blank.col12.clear").select("div#tags").select("ul");
	        					Elements tagsList=tagDiv.select("li");
	        					String tagTemp="";
	        					for(Element tag: tagsList) {
	        						tagTemp=tagTemp+tag.text()+" ";
	        					}
	        					tags=tagTemp.split(" ");
	        										
	        					//get image name from title and append format
	        					String imagefileName=imgTitle+"_image";
	        					int tempstr = imgurl.lastIndexOf(".");
	        			        String format = imgurl.substring(tempstr);
	        			       // imagefileName = imagefileName+format;
	        			        
	        			        String c= imagefileName;
	        			        Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
	        			        Matcher match= pt.matcher(c);
	        			        while(match.find())
	        			        {
	        			            String s= match.group();
	        			        c=c.replaceAll("\\"+s, " ");
	        			        }
	        			        
	        			        imagefileName=c;
	        			        imagefileName = imagefileName+format;
	        			        
	        			        
	        					
	        			      
	        			        String opDir=outputDir+"/EtsyCrawledImgs/";
	        			        File directory = new File(opDir);
	        				    if (! directory.exists()){
	        				        directory.mkdirs();
	        				    }
	        				    //download image 
	        			        downloadimgEtsy.download(imgurl,imagefileName,opDir);
	        					
	        					
	        					
	        					//write the json object and append it to array
	        					jsonwrite.createJsonObj(imgLinkToCrawl,imgurl, imgTitle, size, author, authorLink, imgDecsription, price, views, fav, medium, tags,imagefileName);
	        					
	        				}catch(Exception insideloop) {
	        					//System.out.println("");
	        				}
	        					//remove the crawled link from imageQ
	        					imageLinksEtsy.RemoveItem(0);
	        			  
	        					//wait for sometime before crawling the next image
	        					Thread.sleep(DELAY[delayCounter%4]*1000);
	        					delayCounter++;
	        			
	        			 
	        			}
	        			if(delayCounter>10)
	        				delayCounter=0;
	        			
	        		}catch(Exception outerloop) {
	        			//do something?
	        		}
	        		Q2.RemoveItem(0);
	        		
	        	}
	        	//write the json file
	        	jsonwrite.writeToFile(outputDir+"/"+"imagesEtsy.json");
	        	System.out.println("Completed Etsy");
	        	//wait before terminating
	        	Thread.sleep(4*1000);
	            
	            
	        	
	        	
	        }  catch (Exception e)
	        {
	            // Throwing an exception
	            System.out.println (e);
	        }
	    }   
}
