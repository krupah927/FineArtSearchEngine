import java.io.File;
import java.io.PrintWriter;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class FizdiCrawler extends Thread {

	QueueLinks Q4 = new QueueLinks();
	QueueLinks paintingLinksQ = new QueueLinks();
	DownloadImages downloadimg = new DownloadImages();
	int pageLimit;
	String outputDir;
	QueueLinks hashsetQ=new QueueLinks(); //hashset q to check duplication
	public FizdiCrawler(QueueLinks q4, QueueLinks hs,int pages,String dir) {
		// TODO Auto-generated constructor stub
		Q4 = q4;
		hashsetQ = hs;
		pageLimit=pages;
		outputDir=dir;
	}
	
	public void run() {
		try {
			
			JsonWriter jsonwrite = new JsonWriter();
			//declare all attributes to null Strings
			
			String paintingToCrawl=null, imgSrc = null, paintingTitle=null, artist=null, paintingDescription = null, price = null, paintingDimensions=null, artistUrl=null;
			String views = null, fav = null, medium = null;
			//paintingToCrawl = imgSrc = paintingTitle = artist = paintingDescription = price = paintingDimensions = authUrl = views = fav = medium = null;
			String tagLabels[] = new String[2];
			String tags[] = null;
			
			int crawlCounter=1;
			
			//file to keep track of last page crawled
			File file = new File(outputDir+"/"+"lastFizdipage.txt");
			
			
			while(!Q4.isEmpty()) {
				try {
				String linkToScrape = Q4.getItem(0);
				
				
				System.out.println("Fizdi: "+linkToScrape);
				
				file.createNewFile();
				PrintWriter writer = new PrintWriter(file); 
				writer.write(linkToScrape);
				writer.close();
				
	    		Document document = Jsoup.connect(linkToScrape).get();
	    		
	    		
	    		//getting paintingURLs on this page of the website
	    		Elements containerDivs = document.getElementsByClass("CategoryContent");
	    		Elements outerImageDiv	= containerDivs.select(".ProductList");
	    		Elements imageDivs = outerImageDiv.select(".ProductImage");
	    		
	    		int i = 0;
	    		for(Element elem : imageDivs) {
	    			i++;
	    			String paintingURL = elem.select("a").attr("abs:href");
	    			if(!hashsetQ.crawledpages.contains(paintingURL)) {
	    				hashsetQ.crawledpages.add(paintingURL);
	    				paintingLinksQ.addString(paintingURL);
	    		
	    			}
	    			
	    		}
	    			
	    		
	    		//getting the next page of the website
	    		Elements pagination = document.getElementsByClass("CategoryPagination");
	    		String nextPageURL = pagination.select("a.nav-next").attr("abs:href");
	    		
	    		if(crawlCounter<pageLimit) {
	    			Q4.addString(nextPageURL);
	    			crawlCounter++;
	    		}
	    		
	    		while(!paintingLinksQ.isEmpty()) {
	    			try {
	    			//now crawling the painting page
	    			
	    			//getting painting URL
	    			paintingToCrawl = paintingLinksQ.getItem(0);
	    			
	    			Document paintingDoc = Jsoup.connect(paintingToCrawl).get();
	    			System.out.println("Fizdi Crawling image: "+paintingToCrawl);
	    			
	    			//getting image
	    			Elements imageSrcDiv = paintingDoc.select("div.ProductThumbImage");
	    			imgSrc = imageSrcDiv.select("img").attr("src"); 
	    		
	    			
	    			//getting tags
	    			String tagsLine = imageSrcDiv.select("img").attr("alt");
	    		
	    			tags = tagsLine.split(",");
	    			
	    			
	    			//getting Painting Title
	    			Elements paintingBlockContentDiv = paintingDoc.select("div.BlockContent");
	    			paintingTitle = paintingBlockContentDiv.select("div.left-content .ProductDetailsGrid.mobile .DetailRow h1").text();
	    		
	    			
	    			//getting Painting Artist
	    			artist = paintingBlockContentDiv.select("div.left-content .ProductDetailsGrid.mobile .DetailRow .Value a").text();
	    			
	    			artistUrl = paintingBlockContentDiv.select("div.left-content .ProductDetailsGrid.mobile .DetailRow .Value a").attr("abs:href");
	    			
	    			
	    			//getting Painting Price
	    			price = paintingBlockContentDiv.select("div.DetailRow.PriceRow.p-price .Value .ProductPrice.VariationProductPrice").first().text();
	    			
	    			
	    			//painting details
	    			String line = paintingDoc.select(".ProductWarrantyContainer").html();
	    			String tokens [] = line.split("<br>");
	    			
	    			//painting dimensions
	    			paintingDimensions = tokens[1].substring(7);
	    			
	    			
	    			//painting medium
	    			medium = tokens[2].substring(10);
	    			
	    			
	    			//getting tags for the painting
	    			tagLabels[0] = tokens[0].substring(13);
	    			tagLabels[1] = tokens[3].substring(11);
	    			
	    			
	    			
	    			//get image name from title and append format
					String imageFileName=paintingTitle+"_image";
					String format = imgSrc.substring(imgSrc.lastIndexOf("."), imgSrc.indexOf("?"));
			        imageFileName = imageFileName+format;
			        
	    			
			        String opDir=outputDir+"/FizdiCrawledImgs/";
			        File directory = new File(opDir);
				    if (! directory.exists()){
				        directory.mkdirs();
				    }
				    
	    			downloadimg.download(imgSrc, imageFileName, opDir);
	    			
	    			
	    			
	    			//writing to json
	    			jsonwrite.createJsonObj(paintingToCrawl, imgSrc, paintingTitle, paintingDimensions, artist, artistUrl, paintingDescription, price, views, fav, medium, tags,imageFileName);
	    			
	    			}catch (Exception insideLoop) {
	    				System.out.println("Exception innerLoop: "+insideLoop);
	    			}
	    			//remove crawled link
	    			paintingLinksQ.RemoveItem(0);
	    			
	    			Thread.sleep(3*1000);
	    		}
				}catch(Exception outerLoop) {
					System.out.println("Exception outerLoop: "+outerLoop);
				}
	    		Q4.RemoveItem(0);
	    		
			}
			
			
			jsonwrite.writeToFile(outputDir+"/"+"imagesFizdi.json");
			System.out.println("Completed Fizdi");
			Thread.sleep(5*1000);
			
		}
		catch(Exception e) {
			System.out.println("Overall exception: "+e);
			
		}	
	}
	
	
}
