import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

class SaatchiCrawler extends Thread
{
	QueueLinks Q1 = new QueueLinks(); //queue for pagination
	QueueLinks imageLinksQ = new QueueLinks(); //queue for images
	DownloadImages downloadimg= new DownloadImages(); //to download the images
	QueueLinks hashsetQ=new QueueLinks(); //hashset to check for duplication
	public static int[] DELAY = {7,6,9,8};
	int pageLimit;
	String outputDir;
	int delayCounter=0; //to iterate trough delay
	
	public SaatchiCrawler(QueueLinks q1,QueueLinks hs1,int pages,String dir) throws IOException {
		// TODO Auto-generated constructor stub 
		 Q1= q1;
		 hashsetQ=hs1;
		 pageLimit=pages;
		 outputDir=dir;
		 
	}
	//thread run method
    public void run()
    {
    	
        try
        { 
        	//jsonWriter object to write json file
        	JsonWriter jsonwrite =new JsonWriter();
        	
        	//these info have to parsed from crawled page initialize everything to null.
        	String  imgurl =null;
        	String  imgTitle = null;
        	String  size  =null;
        	String  author  =null;
        	String  authorLink =null;
        	String  imgDecsription =null;
        	String  price =null;
        	String  views =null;
        	String  fav =null;
        	String  medium =null;
        	String [] tags=null;
        	String src=null;
        	File file = new File(outputDir+"/"+"lastSaatchipage.txt");
        	int crawlCounter=1; //limit crawling to certain number of pages
        	while(!Q1.isEmpty()) {
        		try {
        			String linkToScrape = Q1.getItem(0); //get link from queue to get images on that page
        			
        			System.out.println("Saatchi :"+linkToScrape);       			
        			//write the last page crawled to file
        			file.createNewFile();
    				PrintWriter writer = new PrintWriter(file); 
    				writer.write(linkToScrape);
    				writer.close();
        			
        			Document document = Jsoup.connect(linkToScrape).get(); //connect to the page
        		
        			//get the div containing pics
        			Elements outerUL=document.getElementsByAttributeValue("class","item-list masonry");
        			Elements firstDiv= outerUL.select("div.list-art-image");
        			Elements imglinks= firstDiv.select("div.list-art-image-wrapper a");
        	
        			//get links of images and add them to imageLinkQ and hashset
        			for (Element link : imglinks) {
        				String absHref = link.attr("abs:href");
        				
        				//Check if image is already taken
        				
        				if(! hashsetQ.crawledpages.contains(absHref)) {
        					hashsetQ.crawledpages.add(absHref);
        					imageLinksQ.addString(absHref);
        				}
        			}

			
        			//get the url of next page 
        			Elements pagination=document.getElementsByAttributeValue("class","so-pagination");
        			Elements pages=pagination.select("ul.pull-right.pages");
        			Element nextpage=pages.select("li").last().previousElementSibling().select("a").first();
        				
        			//Element nextAnchor
        			String nextLink=nextpage.attr("abs:href");
        		
        			if(crawlCounter<pageLimit) {
        			//add the next page url to q1
        					Q1.addString(nextLink);
        					crawlCounter++;
        			}
        				 
        			//wait for sometime
        			Thread.sleep(DELAY[delayCounter%4]*1000);
        			delayCounter++;
        			
        			//go to the image links and crawl image details 
        			while(!imageLinksQ.isEmpty()) {
        				try {
        					
        					//get image link to crawl.
        					String imgLinkToCrawl=imageLinksQ.getItem(0);
        					System.out.println("Saatchi crawled image: "+imgLinkToCrawl);
        					    			
        					//connect to the image page
        					Document imgDocument = Jsoup.connect(imgLinkToCrawl).get();
        			 
        					//get image source
        					Elements paintingDiv=imgDocument.select(".art-detail-body");
        					Element getImg=paintingDiv.select("li").get(0);
        					imgurl=getImg.select("img").attr("abs:src");
        					
        					//System.out.println(imgurl);
        			    
        					//get image title
        					Elements imgDiv=imgDocument.select("div.small-12.medium-6.large-12.columns.art-meta");
        					Elements getTitle= imgDiv.select("h3.title");
        					imgTitle=getTitle.text();
        			 
        					//get name of the author
        					Element authorDetails=imgDiv.select("p a").first();
        					author=authorDetails.text();
        			 
        					//link to the author's page 
        					Element authUrl=authorDetails.select("a").first();
        					authorLink = authUrl.attr("abs:href");
        			
        					//size of the painting
        					size =imgDiv.select("p.category-size").text().split(":")[1];
        
        					//price of the painting
        					Elements priceDiv=imgDocument.select("div.small-12.medium-6.large-12.columns");
        					Element getPrice=priceDiv.select("div.small-6.large-6.columns span").first();
        					price = getPrice.text();
        			
        					//description of the image
        					Elements descrptionDiv =imgDocument.select(".description");
        					Element description= descrptionDiv.select("div.row").get(1);
        					Element DescriptionText= description.select("p").get(1);
        					imgDecsription=DescriptionText.text();
        			
        					//get tags of the image 
        					String keywords=description.select("p").get(2).text();
        					//get keywords
        					keywords=keywords.split(":")[1];
        					//get subject
        					String keyword2=description.select("p").get(3).text().split(":")[1];
        					//get style
        					String keyword3= description.select("p").get(4).text().split(":")[1];
        					//combine these to keywords
        					keywords= keywords+","+keyword2+","+keyword3;
        					//get medium
        					medium= description.select("p").get(5).text().split(":")[1];
        					//get tags from keywords
        					tags= keywords.split(",");
        			 
        					//get views and favorites 
        					Elements statsDiv=imgDocument.select("div.art-detail-stats ul");
        					String stats= statsDiv.select("li").text();
        					views=stats.split(" ")[0];
        					fav=stats.split(" ")[2];
        			 
        					//get image name from title and append format
        					String imagefileName=imgTitle+"_image";
        					int temp = imgurl.lastIndexOf(".");
        			        String format = imgurl.substring(temp);
        			       // imagefileName = imagefileName+format;
        			        
        			        String c= imagefileName;
        			        Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
        			        Matcher match= pt.matcher(c);
        			        while(match.find())
        			        {
        			            String s= match.group();
        			        c=c.replaceAll("\\"+s, " ");
        			        }
        			        
        			        imagefileName=c;
        			        imagefileName = imagefileName+format;
        			        String opDir=outputDir+"/SaatchiCrawledImgs/";
        			        File directory = new File(opDir);
        				    if (! directory.exists()){
        				        directory.mkdirs();
        				    }
        					
        			        //download image 
        					downloadimg.download(imgurl,imagefileName,opDir);
        					
        					//create a json object to store all these info of image 
        					jsonwrite.createJsonObj(imgLinkToCrawl,imgurl, imgTitle, size, author, authorLink, imgDecsription, price, views, fav, medium, tags,imagefileName);
        				
        					
        				}catch(Exception insideloop) {
        					//System.out.println("");
        					System.out.println("exception inner loop" +insideloop);
                			insideloop.printStackTrace();
        				}
        				//remove the crawled link from imageQ
        					imageLinksQ.RemoveItem(0);
        			  
        					
        				//wait for sometime before crawling the next image
        					Thread.sleep(DELAY[delayCounter%4]*1000);
    	        			delayCounter++;
    	        			
    	        			if(delayCounter>10)
    	        				delayCounter=0;
        			}
        			
        			
        			
        		}catch(Exception outerloop) {
        			//do something?
        			System.out.println("exception"+outerloop);
        			outerloop.printStackTrace();
        		}
        		
        		
				
        		
        		Q1.RemoveItem(0);
        		
        	}
        	//write the json file
        	jsonwrite.writeToFile(outputDir+"/"+"imagesSaatchi.json");
        	System.out.println("Completed Saatchi");
        	//wait before terminating
        	Thread.sleep(4*1000);
            
            
        	
        	
        }  catch (Exception e)
        {
            // Throwing an exception
            System.out.println (e);
        }
    }   
}
