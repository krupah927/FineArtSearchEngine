import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.regex.Matcher;
import java.util.regex.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.jsoup.HttpStatusException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class FineArtAmericaCrawler extends Thread{
	QueueLinks Q5 = new QueueLinks();
	QueueLinks imageURL = new QueueLinks();
	QueueLinks crawledHashSet =new QueueLinks();
	DownloadImages downloadimg= new DownloadImages();
	int pageLimit;
	String outputDir;
	public FineArtAmericaCrawler(QueueLinks q5, QueueLinks hs5,int pages,String dir) {
		Q5 = q5;
		crawledHashSet = hs5;
		pageLimit=pages;
		outputDir=dir;
	}
	
	public void run() {
		
		try {
			JsonWriter jsonwrite =new JsonWriter();
			File file = new File(outputDir+"/"+"lastcrawledpageFAAC.txt");
			int crawlCounter = 1;
			while(!Q5.isEmpty()) {
								
				// create the output file
								
				String linkToScrape = Q5.getItem(0);
				
				System.out.println("FineArtsAmerica: "+linkToScrape);
				
				file.createNewFile();
				PrintWriter writer = new PrintWriter(file);
				writer.write(linkToScrape);
				writer.close();
				
				JSONArray list = new JSONArray();
				try {
					Document doc = Jsoup.connect(linkToScrape).get();
					if(doc.getElementsByAttributeValue("class", "searchEngineRightDiv").size() > 0) {
						Elements divHTML = doc.getElementsByAttributeValue("class", "searchEngineRightDiv");
						Elements imageCont = divHTML.select("div#searchEngineResultsParentDiv");
						Elements imagesDiv = imageCont.select("div.searchengineresultdiv");
						int i = 0;
						//Find all paintings on the pages and add to queue 
						for( Element x : imagesDiv) {
							
							Element y = x.select("div").first().select("a").first();
							String url = y.attr("abs:href").toString();
							if(!crawledHashSet.crawledpages.contains(url)) {
								crawledHashSet.crawledpages.add(url);
								imageURL.addString(url);	
							}
							

						}
						
						//Check if next url for next page of paintings exist 
						if(divHTML.select("div").last().select("a.buttonbottomnext").size() > 0) {
							String url = divHTML.select("div a.buttonbottomnext").attr("abs:href").toString();
							
							//Check if number of pages crawled exceeds number of pages given as input
							if(crawlCounter<pageLimit) {
				    			Q5.addString(url);
				    			crawlCounter++;
				    		}
							
						}
					}
					int j=0;
					while(!imageURL.isEmpty()) {
						try {
							String title, desc, author, medium, price, size, aUrl, imgSrc, views, fav;
							int n;
							j++;
							int i=0;
							size = "12 x 18";
							String imageLinkToScrape = imageURL.getItem(0);
							System.out.println("FAAC img: "+imageLinkToScrape);
							Document doc1 = Jsoup.connect(imageLinkToScrape).get();
							Element imageInfo = doc1.getElementById("imagedetailsdiv");
							Element priceDiv;
							
							//Check if price of painting if it exists
							if( doc1.getElementsByClass("dropdownProductsParentDiv").first() != null) {
								priceDiv = doc1.getElementsByClass("dropdownProductsParentDiv").first();
								price = priceDiv.select("p.topLevelProductPrice").html().toString();
							}
							else if(doc1.getElementById("productcontainerdiv") != null){
								priceDiv = doc1.getElementById("productcontainerdiv");
								if( priceDiv.select(".productdiv").size() > 0 ) {
									Element tempDiv = priceDiv.select(".productdiv").first().select("div").get(2); 
									price = tempDiv.select("p").last().select("a span").html().toString();
								}
								else {
									price = "Not Specified";
								}
							}
							else {
								price = "Not Specified";
							}
							Elements tagsDiv = doc1.getElementsByClass("sidebartag");
							Element likesDiv = doc1.getElementById("previousNextDivContainer");
							Element authorUrl = doc1.getElementById("artistLogoDiv");
							Elements imgDiv = doc1.getElementsByClass("leftdiv");
							
							JSONObject json = new JSONObject();
	
							//Get painting title

							title = imageInfo.select("div").get(1).select("p").last().html().toString();

							

							//Get painting artist name

							author = imageInfo.select("div").get(2).select("p").last().html().toString();

							

							//Get painting description

							desc = imageInfo.select("div").get(4).select("p").last().text();

							

							//Get painting medium ex oil painting, water color

							medium = imageInfo.select("div").get(3).select("p").last().html().toString();

							

							//Get artist url 

							aUrl = authorUrl.select("a").get(0).attr("abs:href").toString();

							

							//Get image source

							imgSrc = imgDiv.select("img").attr("abs:src");

							

							//Get Number of views for the painting

							views = imageInfo.select("div").get(6).select("p").last().html().toString().split(" ")[1];

							

							//Get number of favourites

							fav = likesDiv.select("#HeartIconCountDiv").html().toString();

							

							//Find number of tags and store in JSON array
							n = tagsDiv.size();
							JSONArray tag = new JSONArray();
							String tags[] = new String[n];
							for( Element e : tagsDiv) {
								tags[i++] = e.html().toString();
								tag.add(e.html().toString());
							}
							//get image name from title and append format
							String imagefileName=title+"_image";
	                        int temp = imgSrc.lastIndexOf(".");
	                        String format = imgSrc.substring(temp);
	                        // imagefileName = imagefileName+format;
	                        
	                        String c= imagefileName;
	                        Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
	                        Matcher match= pt.matcher(c);
	                        while(match.find()){
	                            String s= match.group();
	                            c=c.replaceAll("\\"+s, "");
	                        }
	                        
	                        imagefileName=c;
	                        imagefileName = imagefileName+format;
	                        
	    			           			        
	    			        String opDir=outputDir+"/FineArtAmericaCrawledImgs/";
        			        File directory = new File(opDir);
        				    if (! directory.exists()){
        				        directory.mkdirs();
        				    }
        					
        			        //download image 
        					downloadimg.download(imgSrc,imagefileName,opDir);
        					
	    			        
        					//Write image information into json object
							jsonwrite.createJsonObj(imageLinkToScrape,imgSrc, title, size, author, aUrl, desc, price, views, fav, medium, tags,imagefileName);
							
						}
						catch(Exception insideloop) {
							System.out.println("Exception innerloop"+imageURL.getItem(0));
							insideloop.getStackTrace();
						}
						//Remove image url that has been crawled
						imageURL.RemoveItem(0);
						
						//Adhering to gentleman's agreement delay of 5 seconds
						Thread.sleep(5 * 1000);
						
					}
				} catch (NullPointerException e) {
			        // TODO Auto-generated catch block
			        e.printStackTrace();
			    } catch (HttpStatusException e) {
			        //e.printStackTrace();
			    } catch (IOException e) {
			        // TODO Auto-generated catch block
			        e.printStackTrace();
			    }
				//Elements divHTML = doc.getElementsByClass("searchEngineRightDiv searchEngineResultsParentDiv");
				
				//Remove url of page containing images that has be crawled
				Q5.RemoveItem(0);
				
				//Write JSON object created into JSON file
				jsonwrite.writeToFile(outputDir+"/"+"imagesfaac.json");
				
				System.out.println("Completed FAAC");
				
				//Adhering to gentleman's agreement delay of 5 seconds
				Thread.sleep(5 * 1000);
			}
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
