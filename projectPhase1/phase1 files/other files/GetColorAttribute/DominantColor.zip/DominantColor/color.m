
function [meanColor, modeColor] = color(image)
%     image = '020811b Malahicha Watch Traditional Art Paintings Abstract Malahicha_image.jpg';

    rgbImg = imread(image);
    
    info = imfinfo(image);
    width = info.Width;
    height = info.Height;

    if(width<height)
       height = width;
       elseif(height<width)
        width = height;
    end
    
    c = 1:width;
    r = 1:height;
     
    pixels = impixel(rgbImg,c,r);

    meanVal = mean(pixels);
    modeVal = mode(pixels);
    

    meanColorVal = meanVal / 255;
    modeColorVal = modeVal / 255;

    [modeColor,~] = colornames('Natural',modeColorVal);
    [meanColor,~] = colornames('Natural',meanColorVal);
    
end



