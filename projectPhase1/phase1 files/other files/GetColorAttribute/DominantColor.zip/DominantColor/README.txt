driver.m:
 
	Main function which loads images one by one 
	from a given directory and calls the color extraction function.
	Later writes the image name and dominant colors to a textfile.
	<image_name; mean_color, mode_color>

color.m:
	
	Returns dominant colors from the painting.

Rest .m files: 

	MATLAB libraries essential for mapping numeric values of colors to a 
	color name string.
