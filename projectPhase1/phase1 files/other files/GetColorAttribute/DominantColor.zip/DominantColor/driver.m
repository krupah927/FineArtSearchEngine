Files=dir('C:\Users\rutuj\Desktop\Color\DeviantAnime\');
disp('------------');
fileID = fopen('C:\Users\rutuj\Desktop\Color\deviantAnimeData.txt','w');

for k=1:length(Files)
    if(k==1 || k==2)
        continue;
    else
        try
        Filename = Files(k).name;
        filename = string(Filename);
        Filepath = strcat('C:\Users\rutuj\Desktop\Color\DeviantAnime\',Filename);
%         disp(Filepath);
        [meanColor,modeColor] = color(Filepath);
        meancolor = string(meanColor);
        modecolor = string(modeColor);
%         disp('mean color');
%         disp(meanColor);
%         disp('mode color');
%         disp(modeColor);
        fprintf(fileID,'%s; %s, %s\r',filename,meancolor,modecolor);
        catch
            disp('error');
        end
    end
    disp(k-2);
end
fclose(fileID);