package convertJson;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class  changeJson {

	public static void main(String[] args) throws ParseException, FileNotFoundException, IOException {
		try {
		//one list for file name other for color
		 ArrayList<String> fileToArray = new ArrayList<String>();
		 ArrayList<String> colorList = new ArrayList<String>();
		 
		 //read file and store to list
	        try (BufferedReader br = new BufferedReader(new FileReader(args[1])))
	        {

	            String sCurrentLine;
	            String[] splitCurrentline;

	            while ((sCurrentLine = br.readLine()) != null) {
	            	splitCurrentline=sCurrentLine.split("\\;");
	                fileToArray.add(splitCurrentline[0]);
	                colorList.add(splitCurrentline[1]);
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        } 
		
	        //parser for json file
		JSONParser parser = new JSONParser();
		
		//to add newly created object
		JSONArray list=new JSONArray();
 
		JSONArray img = (JSONArray) parser.parse(new FileReader(args[0]));

		//for each object in json array do the following
		  for (Object o : img)
		  {
			  //get json file
		    JSONObject imgObject = (JSONObject) o;
		    
		    //get file name field in the object
		    String jsonImgfield=(String) imgObject.get("filename");
		    
		    // get the index of the file in list
		   int index=fileToArray.indexOf(jsonImgfield);
		   
		   //get colors from that index and add to json array
		   JSONArray colors = new JSONArray();
		  
		   String[] colorsplit=colorList.get(index).split(",");
		   colors.add(colorsplit[0]);
		   colors.add(colorsplit[1]);
		   
		   //create new object
		   JSONObject obj = new JSONObject();
		   
		   // add old json objects to new one
		   obj.put("url", imgObject.get("url"));
	        obj.put("title", imgObject.get("title"));
	        obj.put("imgsrc", imgObject.get("imgsrc"));
	        obj.put("price",imgObject.get("price"));
	        obj.put("color", colors);
		    obj.put("artist", imgObject.get("artist"));
	        obj.put("artistURL", imgObject.get("artistURL"));
	        obj.put("size",imgObject.get("size"));
	        obj.put("description",imgObject.get("description"));
	        obj.put("medium",imgObject.get("medium"));
	        obj.put("views",imgObject.get("views"));
	        obj.put("likes",imgObject.get("likes"));
	        obj.put("filename", jsonImgfield);
	        obj.put("tags", imgObject.get("tags"));
	        //add color array to object
	        obj.put("color", colors);
		   
		   
	        list.add(obj);
		  }
		  
		  //write the object to file
		  try (FileWriter file = new FileWriter("result.json")) {

	            file.write(list.toJSONString());
	            file.flush();

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	
	}catch(Exception outertry) {
		System.out.println("could not create file");
	}
	
}

}